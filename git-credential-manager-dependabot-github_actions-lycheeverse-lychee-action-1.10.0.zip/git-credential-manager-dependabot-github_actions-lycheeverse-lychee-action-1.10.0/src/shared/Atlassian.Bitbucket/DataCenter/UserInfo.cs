using System;

namespace Atlassian.Bitbucket.DataCenter
{
    public class UserInfo : IUserInfo
    {
        public string UserName { get; set; }
    }
}
