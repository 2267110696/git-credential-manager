using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Core.Tests")]
[assembly: InternalsVisibleTo("GitHub.Tests")]
[assembly: InternalsVisibleTo("Atlassian.Bitbucket.Tests")]
